<h2>DSExec
  <small class="text-muted">
    <a href="https://github.com/dapphub/ds-exec"><span class="fa fa-github"></span></a>
  </small>
</h2>

_Better exception handling_

Base contract which wraps `.call` with internals `.exec` and `.tryExec`, which 
handle exceptions more naturally.
