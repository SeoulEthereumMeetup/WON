<h2>DSThing
  <small class="text-muted">
    <a href="https://github.com/dapphub/ds-thing"><span class="fa fa-github"></span></a>
  </small>
</h2>

_Your things should be DSThings_
  
DSThing simply inherits from [DSAuth](https://dapp.tools/dappsys/ds-auth.html), 
[DSMath](https://dapp.tools/dappsys/ds-math.html) and 
[DSNote](https://dapp.tools/dappsys/ds-note.html) for 3-in-1 convenience. An 
alias type for blockchain _things_ that use math, log events, and have a concept 
of ownership.
